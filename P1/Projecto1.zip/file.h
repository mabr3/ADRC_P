#include "struct.h"

Tree * PrefixTree(char * nome);